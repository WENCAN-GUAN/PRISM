| stage             | model         |   CDGI |
|:------------------|:--------------|-------:|
| PRISM (aggregate) | PRISM         | 0.7844 |
| 2c_dl             | FTTransformer | 0.5879 |
| 2c_dl             | MLP           | 0.5177 |
| 0_baseline        | Ridge         | 0.2095 |
| 0_baseline        | LightGBM      | 0.0204 |
| 0_baseline        | XGBoost       | 0.0204 |
| 0_baseline        | RandomForest  | 0.0196 |