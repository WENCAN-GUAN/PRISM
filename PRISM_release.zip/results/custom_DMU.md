| dataset    |   RMSE_lagonly |   RMSE_vmd |      DMU | note                                        |
|:-----------|---------------:|-----------:|---------:|:--------------------------------------------|
| Appliances |        58.8770 |    23.9091 |   0.5939 |                                             |
| PM25       |       nan      |   nan      | nan      | missing one of (LagOnly, VMD) for clean DMU |