# Datasets

The four UCI benchmarks are not redistributed in this repository. Download them from the links below and place each one at the path indicated.

## CCPP — Combined Cycle Power Plant

- Source: https://archive.ics.uci.edu/dataset/294/combined+cycle+power+plant
- Reference: P. Tüfekci, *Int. J. Electr. Power Energy Syst.*, vol. 60, pp. 126–140, 2014.
- Expected path: `datasets/01_CCPP/CCPP/Folds5x2_pp.xlsx`

## Concrete Compressive Strength

- Source: https://archive.ics.uci.edu/dataset/165/concrete+compressive+strength
- Reference: I.-C. Yeh, *Cem. Concr. Res.*, vol. 28, no. 12, pp. 1797–1808, 1998.
- Expected path: `datasets/02_Concrete/Concrete_Data.xls`

## Appliances Energy Prediction

- Source: https://archive.ics.uci.edu/dataset/374/appliances+energy+prediction
- Reference: L. M. Candanedo, V. Feldheim, D. Deramaix, *Energy Build.*, vol. 140, pp. 81–97, 2017.
- Expected path: `datasets/03_AppliancesEnergy/energydata_complete.csv`

## Beijing PM2.5

- Source: https://archive.ics.uci.edu/dataset/381/beijing+pm2+5+data
- Reference: X. Liang *et al.*, *Proc. Roy. Soc. A*, vol. 471, no. 2182, art. 20150257, 2015.
- Expected path: `datasets/04_BeijingPM25/PRSA_data_2010.1.1-2014.12.31.csv`

## Custom location

If you keep the data anywhere else, set the environment variable

    export PRISM_DATA_DIR=/path/to/your/datasets

`prism.data` will pick it up.
