"""Out-of-the-box baselines on the four datasets.

Runs Ridge, Random Forest, XGBoost and LightGBM with default hyper-parameters
on each dataset. Static datasets get a random 80/20 split (seed=42); the two
time-series datasets get a chronological 80/20 split, which is what the paper
reports as the raw-baseline rows. Per-dataset CSVs and a combined summary
land in results/baselines/.
"""
from __future__ import annotations
import sys, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
import lightgbm as lgb

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import load_dataset, ALL_DATASETS, all_metrics, set_seed, ensure_dir

SEED = 42
RESULTS = ensure_dir(Path(__file__).resolve().parents[1] / "results" / "baselines")


def split(X: pd.DataFrame, y: pd.Series, time_series: bool):
    if time_series:
        n = len(X)
        cut = int(n * 0.8)
        return X.iloc[:cut], X.iloc[cut:], y.iloc[:cut], y.iloc[cut:]
    return train_test_split(X, y, test_size=0.2, random_state=SEED)


N_JOBS = 8  # 32-core CPU; small datasets oversubscribe with -1


def get_models() -> dict:
    return {
        "Ridge":        Ridge(alpha=1.0, random_state=SEED),
        "RandomForest": RandomForestRegressor(n_estimators=300, n_jobs=N_JOBS, random_state=SEED),
        "XGBoost":      xgb.XGBRegressor(
            n_estimators=500, learning_rate=0.05, max_depth=6,
            subsample=0.9, colsample_bytree=0.9, random_state=SEED,
            tree_method="hist", n_jobs=N_JOBS, verbosity=0,
        ),
        "LightGBM":     lgb.LGBMRegressor(
            n_estimators=500, learning_rate=0.05, max_depth=-1, num_leaves=63,
            subsample=0.9, colsample_bytree=0.9, random_state=SEED,
            n_jobs=N_JOBS, verbosity=-1,
        ),
    }


def run_dataset(name: str) -> pd.DataFrame:
    set_seed(SEED)
    X, y, meta = load_dataset(name)
    print(f"\n=== {name}  samples={meta.n_samples}  features={meta.n_features}  "
          f"time_series={meta.is_time_series} ===")

    Xtr, Xte, ytr, yte = split(X, y, meta.is_time_series)
    scaler = StandardScaler().fit(Xtr)
    Xtr_s = pd.DataFrame(scaler.transform(Xtr), columns=Xtr.columns, index=Xtr.index)
    Xte_s = pd.DataFrame(scaler.transform(Xte), columns=Xte.columns, index=Xte.index)

    rows = []
    for mname, model in get_models().items():
        Xa, Xb = (Xtr_s, Xte_s) if mname == "Ridge" else (Xtr, Xte)
        t0 = time.perf_counter()
        model.fit(Xa, ytr)
        pred = model.predict(Xb)
        dt = time.perf_counter() - t0
        m = all_metrics(yte, pred)
        m.update({"dataset": name, "model": mname, "fit_predict_sec": round(dt, 3)})
        rows.append(m)
        print(f"  {mname:<14}  RMSE={m['RMSE']:.4f}  MAE={m['MAE']:.4f}  "
              f"MAPE={m['MAPE']:.2f}%  R2={m['R2']:.4f}  ({dt:.1f}s)")
    return pd.DataFrame(rows)


def main():
    all_rows = []
    for name in ALL_DATASETS:
        df = run_dataset(name)
        df.to_csv(RESULTS / f"baseline_{name}.csv", index=False)
        all_rows.append(df)
    summary = pd.concat(all_rows, ignore_index=True)
    summary = summary[["dataset", "model", "RMSE", "MAE", "MAPE", "R2", "fit_predict_sec"]]
    summary.to_csv(RESULTS / "baseline_summary.csv", index=False)
    summary.to_markdown(RESULTS / "baseline_summary.md", index=False, floatfmt=".4f")
    print(f"\nSaved → {RESULTS}")
    print("\n" + summary.to_string(index=False))


if __name__ == "__main__":
    main()
