"""PRISM on the two static datasets (CCPP and Concrete).

The targets are not time-indexed, so the lag-feature and VMD stages are
skipped. What's left is ICPO searching the LightGBM hyper-parameter box,
followed by a single LightGBM fit with the best vector. Saves the best
parameters, the convergence trace and the predictions for each dataset.
"""
from __future__ import annotations
import sys, time, json, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split  # noqa: E402

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import load_dataset, all_metrics, set_seed, ensure_dir
from prism.tuning import tune_lightgbm, fit_lgbm

SEED = 42
N_JOBS = 8
DATASETS = ["CCPP", "Concrete"]
RESULTS = ensure_dir(Path(__file__).resolve().parents[1] / "results" / "prism_static")


def run(name: str) -> dict:
    set_seed(SEED)
    X, y, meta = load_dataset(name)
    print(f"\n=== PRISM-static  {name}  shape=({len(X)}, {X.shape[1]}) ===", flush=True)

    Xtv, Xte, ytv, yte = train_test_split(X, y, test_size=0.10, random_state=SEED)
    Xtr, Xv,  ytr, yv  = train_test_split(Xtv, ytv, test_size=0.1111, random_state=SEED)
    print(f"  splits: train={len(Xtr)}  val={len(Xv)}  test={len(Xte)}", flush=True)

    t0 = time.perf_counter()
    best, result = tune_lightgbm(Xtr, ytr, Xv, yv,
                                 n_jobs=N_JOBS, pop_size=15, max_iter=20, seed=SEED)
    tune_sec = time.perf_counter() - t0
    print(f"  ICPO {tune_sec:.1f}s   best val-RMSE={result.best_fitness:.4f}", flush=True)

    Xfull = pd.concat([Xtr, Xv]); yfull = pd.concat([ytr, yv])
    model = fit_lgbm(best, Xfull, yfull, n_jobs=N_JOBS, seed=SEED)
    pred = model.predict(Xte)
    m = all_metrics(yte, pred)
    m.update({"dataset": name, "model": "PRISM-static", "tune_sec": round(tune_sec, 2)})
    print(f"  TEST: RMSE={m['RMSE']:.4f}  MAE={m['MAE']:.4f}  MAPE={m['MAPE']:.2f}%  R2={m['R2']:.4f}", flush=True)

    with (RESULTS / f"{name}_best_params.json").open("w") as f:
        json.dump(best, f, indent=2)
    pd.DataFrame({
        "iter": list(range(len(result.history))),
        "best_fitness": result.history,
    }).to_csv(RESULTS / f"{name}_convergence.csv", index=False)
    np.save(RESULTS / f"{name}_pred.npy", pred)
    np.save(RESULTS / f"{name}_y_test.npy", yte.values)
    return m


def main():
    rows = [run(n) for n in DATASETS]
    summary = pd.DataFrame(rows)[["dataset", "model", "RMSE", "MAE", "MAPE", "R2", "tune_sec"]]
    summary.to_csv(RESULTS / "prism_static_summary.csv", index=False)
    summary.to_markdown(RESULTS / "prism_static_summary.md", index=False, floatfmt=".4f")
    print("\n[PRISM-static summary]\n" + summary.to_string(index=False))


if __name__ == "__main__":
    main()
