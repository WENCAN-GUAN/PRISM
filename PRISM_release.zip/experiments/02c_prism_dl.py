"""Deep tabular baselines: MLP and a small FT-Transformer.

Trains both models on each dataset with AdamW + cosine LR + early stopping.
Splits are identical to the other scripts so the rows in the paper's master
table line up. Time-series datasets reuse the lag-feature set built in
01_features_ts.py. Launch with CUDA_VISIBLE_DEVICES=<idx> if you want to
pin to a specific GPU.
"""
from __future__ import annotations
import os, sys, time, json, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import (
    load_dataset, all_metrics, set_seed, ensure_dir,
    add_lag_features, add_cyclical_time,
)
from prism.dl_models import MLPRegressor, FTTransformerLite, train_torch_regressor, predict

SEED = 42
RESULTS = ensure_dir(Path(__file__).resolve().parents[1] / "results" / "prism_dl")
STATIC = {"CCPP", "Concrete"}
TS = {"Appliances", "PM25"}


def chrono_split(X, y, ratio=0.8):
    cut = int(len(X) * ratio)
    return X.iloc[:cut], X.iloc[cut:], y.iloc[:cut], y.iloc[cut:]


def prepare(name: str):
    X, y, meta = load_dataset(name)
    if meta.is_time_series:
        Xc = add_cyclical_time(X.reset_index(drop=True))
        Xfe, yfe = add_lag_features(Xc, y, target_name=meta.target.replace(".", "_"))
        Xtr_full, Xte, ytr_full, yte = chrono_split(Xfe, yfe)
        sub = int(len(Xtr_full) * 0.85)
        Xtr, Xv = Xtr_full.iloc[:sub], Xtr_full.iloc[sub:]
        ytr, yv = ytr_full.iloc[:sub], ytr_full.iloc[sub:]
    else:
        Xtv, Xte, ytv, yte = train_test_split(X, y, test_size=0.10, random_state=SEED)
        Xtr, Xv,  ytr, yv  = train_test_split(Xtv, ytv, test_size=0.1111, random_state=SEED)
    return (Xtr.values, Xv.values, Xte.values,
            ytr.values, yv.values, yte.values), meta


def run_model(model_name: str, dataset: str) -> dict:
    set_seed(SEED)
    (Xtr, Xv, Xte, ytr, yv, yte), meta = prepare(dataset)
    print(f"\n--- {dataset} | {model_name} | shapes tr/val/te = {Xtr.shape}/{Xv.shape}/{Xte.shape} ---", flush=True)

    sx = StandardScaler().fit(Xtr); sy_mu, sy_sd = float(ytr.mean()), float(ytr.std() + 1e-12)
    Xtr_s, Xv_s, Xte_s = sx.transform(Xtr), sx.transform(Xv), sx.transform(Xte)
    ytr_s, yv_s = (ytr - sy_mu) / sy_sd, (yv - sy_mu) / sy_sd

    in_dim = Xtr.shape[1]
    if model_name == "MLP":
        model = MLPRegressor(in_dim, hidden=(256, 256, 128), dropout=0.15)
        epochs, batch, lr, wd = 250, 256, 1e-3, 1e-4
    else:
        model = FTTransformerLite(in_dim, d_token=64, n_heads=4, n_layers=3, dropout=0.1)
        epochs, batch, lr, wd = 200, 256, 5e-4, 1e-4

    t0 = time.perf_counter()
    info = train_torch_regressor(
        model, Xtr_s, ytr_s, Xv_s, yv_s,
        epochs=epochs, batch_size=batch, lr=lr, weight_decay=wd,
        patience=30, seed=SEED, verbose=False,
    )
    train_sec = time.perf_counter() - t0

    pred_te = predict(model, Xte_s) * sy_sd + sy_mu
    m = all_metrics(yte, pred_te)
    m.update({"dataset": dataset, "model": model_name,
              "epochs_ran": info["epochs_ran"], "train_sec": round(train_sec, 2)})
    print(f"    {model_name:<5} epochs={info['epochs_ran']:3d}  RMSE={m['RMSE']:.4f}  "
          f"MAE={m['MAE']:.4f}  R2={m['R2']:.4f}  ({train_sec:.1f}s)", flush=True)
    return m


def main():
    print("CUDA available:", torch.cuda.is_available(),
          "device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu", flush=True)
    rows = []
    for ds in ["CCPP", "Concrete", "Appliances", "PM25"]:
        for m_name in ["MLP", "FTTransformer"]:
            try:
                rows.append(run_model(m_name, ds))
            except Exception as e:
                print(f"  ! {ds}/{m_name} failed: {e}", flush=True)
    summary = pd.DataFrame(rows)[["dataset", "model", "RMSE", "MAE", "MAPE", "R2", "epochs_ran", "train_sec"]]
    summary.to_csv(RESULTS / "prism_dl_summary.csv", index=False)
    summary.to_markdown(RESULTS / "prism_dl_summary.md", index=False, floatfmt=".4f")
    print("\n[PRISM-DL summary]\n" + summary.to_string(index=False))


if __name__ == "__main__":
    main()
