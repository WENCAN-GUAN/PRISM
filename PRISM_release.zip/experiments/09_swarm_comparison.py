"""Side-by-side comparison of ICPO against five other optimisers.

All six (Random Search, GA, PSO, GWO, vanilla CPO, ICPO) get the same
fitness function, the same nine-dimensional LightGBM search box, and the
same evaluation budget (population 15 x 20 iterations, about 315 fits each).
Concrete is used because the dataset is static and small enough that the
optimiser comparison is not muddied by distribution shift. The convergence
curves and final test-RMSE / wall-time values are written to
results/swarm_compare/.
"""
from __future__ import annotations
import sys, time, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import load_dataset, all_metrics, set_seed, ensure_dir
from prism.tuning import LGBM_BOUNDS, decode_lgbm, fit_lgbm
from prism.metrics import rmse
from prism.optimizer import ICPO
from prism import swarm_baselines as sw
import lightgbm as lgb

SEED = 42
N_JOBS = 8
POP, MITR = 15, 20
N_EVALS = POP * (MITR + 1)
DATASET = "Concrete"
RESULTS = ensure_dir(Path(__file__).resolve().parents[1] / "results" / "swarm_compare")


def make_objective(X_tr, y_tr, X_val, y_val, seed):
    names = list(LGBM_BOUNDS.keys())
    lb = np.array([LGBM_BOUNDS[n][0] for n in names], dtype=float)
    ub = np.array([LGBM_BOUNDS[n][1] for n in names], dtype=float)
    def f(theta):
        params = decode_lgbm(theta, names)
        m = lgb.LGBMRegressor(**params, random_state=seed, n_jobs=N_JOBS,
                              verbosity=-1, subsample_freq=1, force_col_wise=True)
        m.fit(X_tr, y_tr)
        return rmse(y_val, m.predict(X_val))
    return f, lb, ub, names


def main():
    set_seed(SEED)
    X, y, _ = load_dataset(DATASET)
    Xtv, Xte, ytv, yte = train_test_split(X, y, test_size=0.10, random_state=SEED)
    Xtr, Xv, ytr, yv = train_test_split(Xtv, ytv, test_size=0.1111, random_state=SEED)
    f, lb, ub, names = make_objective(Xtr, ytr, Xv, yv, SEED)

    runs = [
        ("RandomSearch", lambda: sw.random_search(f, lb, ub, n_evals=N_EVALS, seed=SEED)),
        ("GA",           lambda: sw.ga(f, lb, ub, pop_size=POP, max_iter=MITR, seed=SEED)),
        ("PSO",          lambda: sw.pso(f, lb, ub, pop_size=POP, max_iter=MITR, seed=SEED)),
        ("GWO",          lambda: sw.gwo(f, lb, ub, pop_size=POP, max_iter=MITR, seed=SEED)),
        ("CPO_vanilla",  lambda: ICPO(f, lb, ub, pop_size=POP, max_iter=MITR,
                                      seed=SEED, use_tent=False, use_levy=False, use_elite=False).run()),
        ("ICPO",         lambda: ICPO(f, lb, ub, pop_size=POP, max_iter=MITR, seed=SEED).run()),
    ]

    rows = []
    for name, fn in runs:
        set_seed(SEED)
        t0 = time.perf_counter()
        result = fn()
        opt_sec = time.perf_counter() - t0
        # unify access to history and best
        hist = result.history if hasattr(result, "history") else result["history"]
        best_x = result.best_x if hasattr(result, "best_x") else result["best_x"]
        best_val_rmse = float(result.best_fitness if hasattr(result, "best_fitness") else result["best_fitness"])

        params = decode_lgbm(best_x, names)
        Xfull = pd.concat([Xtr, Xv]); yfull = pd.concat([ytr, yv])
        model = fit_lgbm(params, Xfull, yfull, n_jobs=N_JOBS, seed=SEED)
        pred = model.predict(Xte)
        m = all_metrics(yte, pred)
        m.update({"optimizer": name, "opt_sec": round(opt_sec, 2),
                  "best_val_rmse": best_val_rmse, "evals": len(hist) * (POP if name not in ("RandomSearch",) else 1)})
        rows.append(m)
        pd.DataFrame({"iter": range(len(hist)), "best_fitness": hist}
                     ).to_csv(RESULTS / f"convergence_{name}.csv", index=False)
        print(f"{name:<14} val-RMSE={best_val_rmse:.4f}  test RMSE={m['RMSE']:.4f}  R2={m['R2']:.4f}  ({opt_sec:.1f}s)",
              flush=True)

    df = pd.DataFrame(rows)[["optimizer", "RMSE", "MAE", "MAPE", "R2", "best_val_rmse", "opt_sec"]]
    df = df.sort_values("RMSE")
    df.to_csv(RESULTS / "swarm_compare.csv", index=False)
    df.to_markdown(RESULTS / "swarm_compare.md", index=False, floatfmt=".4f")
    print("\n[Swarm comparison summary, sorted by test RMSE]\n" + df.to_string(index=False))


if __name__ == "__main__":
    main()
