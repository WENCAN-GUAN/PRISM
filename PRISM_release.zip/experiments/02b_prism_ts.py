"""PRISM on the two time-series datasets.

Different configurations per dataset, picked by the selective-activation rule
described in the paper:

  Appliances : lag/rolling/cyclical features + VMD with K=8 modes + ICPO-tuned
               LightGBM per mode, summed back to a single prediction.
  PM2.5      : lag/rolling/cyclical features + ICPO-tuned LightGBM. VMD is
               skipped because the lag-only configuration already saturates
               R² above 0.95 and the DMU pre-check returns near zero.

For each run we save the best hyper-parameters, the per-mode specs (when
VMD is on), the convergence trace and the test predictions.
"""
from __future__ import annotations
import sys, time, json, warnings
from pathlib import Path
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import (
    load_dataset, all_metrics, set_seed, ensure_dir,
    add_lag_features, add_cyclical_time,
)
from prism.features import DEFAULT_LAGS, DEFAULT_WINDOWS
from prism.tuning import tune_lightgbm, fit_lgbm

SEED = 42
N_JOBS = 8
K_MODES = 8
VMD_ALPHA = 2000
RESULTS = ensure_dir(Path(__file__).resolve().parents[1] / "results" / "prism_ts")
MAX_LAG = max(max(DEFAULT_LAGS), max(DEFAULT_WINDOWS))


def vmd_decompose(y: np.ndarray, K: int = K_MODES) -> np.ndarray:
    from vmdpy import VMD
    n = len(y)
    y_in = y if n % 2 == 0 else np.append(y, y[-1])
    modes, _, _ = VMD(y_in, alpha=VMD_ALPHA, tau=0.0, K=K, DC=False, init=1, tol=1e-7)
    if modes.shape[1] > n:
        modes = modes[:, :n]
    elif modes.shape[1] < n:
        diff = n - modes.shape[1]
        modes = np.concatenate([modes, np.tile(modes[:, -1:], (1, diff))], axis=1)
    return modes


def chrono_split(X: pd.DataFrame, y: pd.Series, ratio: float = 0.8):
    cut = int(len(X) * ratio)
    return X.iloc[:cut], X.iloc[cut:], y.iloc[:cut], y.iloc[cut:]


def run_appliances() -> dict:
    name = "Appliances"
    set_seed(SEED)
    X, y, meta = load_dataset(name)
    print(f"\n=== PRISM-TS  {name}  raw shape=({len(X)}, {X.shape[1]}) ===", flush=True)

    Xc = add_cyclical_time(X.reset_index(drop=True))
    y_arr = y.reset_index(drop=True).to_numpy(dtype=float)

    print(f"  VMD K={K_MODES} α={VMD_ALPHA} ...", end=" ", flush=True)
    t0 = time.perf_counter()
    modes = vmd_decompose(y_arr, K=K_MODES)
    print(f"{time.perf_counter()-t0:.1f}s  modes={modes.shape}", flush=True)
    recon_err = float(np.mean((y_arr - modes.sum(axis=0)) ** 2) ** 0.5)
    print(f"  VMD reconstruction RMSE={recon_err:.4f}", flush=True)

    n_after = len(y_arr) - MAX_LAG
    cut = int(n_after * 0.8)
    mode_preds = np.zeros((K_MODES, n_after - cut))
    mode_specs = []

    for k in range(K_MODES):
        mode_series = pd.Series(modes[k], name=f"mode{k}")
        Xfe, yfe = add_lag_features(Xc, mode_series, target_name=f"mode{k}")
        Xtr_full, Xte = Xfe.iloc[:cut], Xfe.iloc[cut:]
        ytr_full, yte = yfe.iloc[:cut], yfe.iloc[cut:]
        sub = int(len(Xtr_full) * 0.85)
        Xt, Xv = Xtr_full.iloc[:sub], Xtr_full.iloc[sub:]
        yt, yv = ytr_full.iloc[:sub], ytr_full.iloc[sub:]

        print(f"  mode{k} (std={yfe.std():.3f}): tuning...", end=" ", flush=True)
        t0 = time.perf_counter()
        best, _ = tune_lightgbm(Xt, yt, Xv, yv,
                                n_jobs=N_JOBS, pop_size=10, max_iter=15, seed=SEED + k)
        model = fit_lgbm(best, Xtr_full, ytr_full, n_jobs=N_JOBS, seed=SEED)
        mode_preds[k] = model.predict(Xte)
        mode_specs.append({"mode": k, "best_params": best,
                           "tune_sec": round(time.perf_counter() - t0, 2),
                           "mode_std": float(yfe.std())})
        print(f"{time.perf_counter()-t0:.1f}s", flush=True)

    final_pred = mode_preds.sum(axis=0)
    y_real_test = y_arr[MAX_LAG:][cut:]
    m = all_metrics(y_real_test, final_pred)
    m.update({"dataset": name, "model": "PRISM-TS-VMD", "K": K_MODES})
    print(f"  TEST: RMSE={m['RMSE']:.4f}  MAE={m['MAE']:.4f}  MAPE={m['MAPE']:.2f}%  R2={m['R2']:.4f}",
          flush=True)

    with (RESULTS / f"{name}_mode_specs.json").open("w") as f:
        json.dump(mode_specs, f, indent=2)
    np.save(RESULTS / f"{name}_mode_preds.npy", mode_preds)
    np.save(RESULTS / f"{name}_y_test.npy", y_real_test)
    return m


def run_pm25() -> dict:
    name = "PM25"
    set_seed(SEED)
    X, y, meta = load_dataset(name)
    print(f"\n=== PRISM-TS  {name}  raw shape=({len(X)}, {X.shape[1]}) ===", flush=True)

    Xc = add_cyclical_time(X.reset_index(drop=True))
    Xfe, yfe = add_lag_features(Xc, y, target_name=meta.target.replace(".", "_"))
    Xtr_full, Xte, ytr_full, yte = chrono_split(Xfe, yfe)
    sub = int(len(Xtr_full) * 0.85)
    Xt, Xv = Xtr_full.iloc[:sub], Xtr_full.iloc[sub:]
    yt, yv = ytr_full.iloc[:sub], ytr_full.iloc[sub:]
    print(f"  shapes: train={Xt.shape}  val={Xv.shape}  test={Xte.shape}", flush=True)

    print(f"  ICPO tuning LightGBM (no VMD)...", end=" ", flush=True)
    t0 = time.perf_counter()
    best, result = tune_lightgbm(Xt, yt, Xv, yv,
                                 n_jobs=N_JOBS, pop_size=15, max_iter=20, seed=SEED)
    tune_sec = time.perf_counter() - t0
    print(f"{tune_sec:.1f}s  best val-RMSE={result.best_fitness:.4f}", flush=True)

    model = fit_lgbm(best, Xtr_full, ytr_full, n_jobs=N_JOBS, seed=SEED)
    pred = model.predict(Xte)
    m = all_metrics(yte, pred)
    m.update({"dataset": name, "model": "PRISM-TS-LagOnly", "K": 0})
    print(f"  TEST: RMSE={m['RMSE']:.4f}  MAE={m['MAE']:.4f}  MAPE={m['MAPE']:.2f}%  R2={m['R2']:.4f}",
          flush=True)

    with (RESULTS / f"{name}_best_params.json").open("w") as f:
        json.dump(best, f, indent=2)
    pd.DataFrame({
        "iter": list(range(len(result.history))),
        "best_fitness": result.history,
    }).to_csv(RESULTS / f"{name}_convergence.csv", index=False)
    np.save(RESULTS / f"{name}_pred.npy", pred)
    np.save(RESULTS / f"{name}_y_test.npy", yte.to_numpy())
    return m


def main():
    rows = [run_appliances(), run_pm25()]
    summary = pd.DataFrame(rows)[["dataset", "model", "RMSE", "MAE", "MAPE", "R2", "K"]]
    summary.to_csv(RESULTS / "prism_ts_summary.csv", index=False)
    summary.to_markdown(RESULTS / "prism_ts_summary.md", index=False, floatfmt=".4f")
    print("\n[PRISM-TS summary]\n" + summary.to_string(index=False))


if __name__ == "__main__":
    main()
