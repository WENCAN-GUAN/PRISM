"""Three-component ablation of ICPO on the Concrete dataset.

We turn the three new mechanisms off one at a time and re-run the same
LightGBM tuning task:

  vanilla CPO    (none of Tent / Levy / Elite)
  ICPO - Tent    (Tent-chaotic init replaced by uniform sampling)
  ICPO - Levy    (Levy-flight perturbation replaced by Gaussian)
  ICPO - Elite   (no elite blending in the update)
  ICPO  full     (everything on; this matches 02a)

Test RMSE for each variant is written to results/ablation/ablation_concrete.*.
The VMD ablation is computed elsewhere (07_custom_metrics.py) by comparing
PRISM-TS-VMD against PRISM-TS-LagOnly on Appliances.
"""
from __future__ import annotations
import sys, time, json, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import load_dataset, all_metrics, set_seed, ensure_dir
from prism.tuning import tune_lightgbm, fit_lgbm

SEED = 42
N_JOBS = 8
RESULTS = ensure_dir(Path(__file__).resolve().parents[1] / "results" / "ablation")
DATASET = "Concrete"


CONFIGS = [
    ("CPO_vanilla",    dict(use_tent=False, use_levy=False, use_elite=False)),
    ("ICPO_minus_Tent", dict(use_tent=False, use_levy=True,  use_elite=True)),
    ("ICPO_minus_Levy", dict(use_tent=True,  use_levy=False, use_elite=True)),
    ("ICPO_minus_Elite",dict(use_tent=True,  use_levy=True,  use_elite=False)),
    ("ICPO_full",       dict(use_tent=True,  use_levy=True,  use_elite=True)),
]


def main():
    set_seed(SEED)
    X, y, _ = load_dataset(DATASET)
    Xtv, Xte, ytv, yte = train_test_split(X, y, test_size=0.10, random_state=SEED)
    Xtr, Xv, ytr, yv = train_test_split(Xtv, ytv, test_size=0.1111, random_state=SEED)

    rows = []
    for name, flags in CONFIGS:
        set_seed(SEED)
        t0 = time.perf_counter()
        best, result = tune_lightgbm(
            Xtr, ytr, Xv, yv,
            n_jobs=N_JOBS, pop_size=15, max_iter=20, seed=SEED, **flags
        )
        tune_sec = time.perf_counter() - t0
        Xfull = pd.concat([Xtr, Xv]); yfull = pd.concat([ytr, yv])
        model = fit_lgbm(best, Xfull, yfull, n_jobs=N_JOBS, seed=SEED)
        pred = model.predict(Xte)
        m = all_metrics(yte, pred)
        m.update({"variant": name, "tune_sec": round(tune_sec, 2),
                  "best_val_rmse": result.best_fitness})
        rows.append(m)
        # save convergence
        pd.DataFrame({"iter": range(len(result.history)), "best_fitness": result.history}
                     ).to_csv(RESULTS / f"convergence_{name}.csv", index=False)
        print(f"{name:<22} val-RMSE={result.best_fitness:.4f}  test RMSE={m['RMSE']:.4f}  R2={m['R2']:.4f}",
              flush=True)

    # add VMD ablation (Appliances) using existing data
    res_root = Path(__file__).resolve().parents[1] / "results"
    appliances_full = res_root / "prism_ts" / "prism_ts_summary.csv"
    appliances_lago = res_root / "prism_ts" / "Appliances_lagonly.csv"
    if appliances_full.exists() and appliances_lago.exists():
        full = pd.read_csv(appliances_full)
        full = full[(full["dataset"] == "Appliances") & (full["model"] == "PRISM-TS-VMD")]
        lago = pd.read_csv(appliances_lago)
        if len(full) and len(lago):
            rmse_full = float(full["RMSE"].iloc[0])
            rmse_lago = float(lago["RMSE"].iloc[0])
            print(f"\nVMD ablation on Appliances:  RMSE_VMD={rmse_full:.3f}  "
                  f"RMSE_LagOnly={rmse_lago:.3f}  ΔRMSE={(rmse_lago-rmse_full)/rmse_lago*100:.1f}%",
                  flush=True)

    df = pd.DataFrame(rows)[["variant", "RMSE", "MAE", "MAPE", "R2", "best_val_rmse", "tune_sec"]]
    df.to_csv(RESULTS / "ablation_concrete.csv", index=False)
    df.to_markdown(RESULTS / "ablation_concrete.md", index=False, floatfmt=".4f")
    print("\n[Concrete ablation summary]\n" + df.to_string(index=False))


if __name__ == "__main__":
    main()
