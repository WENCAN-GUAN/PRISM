"""Compute the three custom metrics introduced in the paper: CDGI, DSRR, DMU.

CDGI is the geometric mean of (1 - NRMSE_d) across datasets; it punishes
methods that fail on any single dataset. DSRR is reported per time-series
dataset and answers "is the model worse than predicting the unconditional
mean" with a zero threshold. DMU compares PRISM-TS-VMD against
PRISM-TS-LagOnly on Appliances and gives the share of the RMSE drop that
can be attributed to the VMD step alone. All three are written into
results/custom_*.csv and the matching .md files.
"""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import load_dataset, ensure_dir
from prism.features import DEFAULT_LAGS, DEFAULT_WINDOWS

SEED = 42
ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"
MAX_LAG = max(max(DEFAULT_LAGS), max(DEFAULT_WINDOWS))


def y_test_stats():
    stats = {}
    for ds in ["CCPP", "Concrete", "Appliances", "PM25"]:
        X, y, meta = load_dataset(ds)
        if meta.is_time_series:
            yt = y.reset_index(drop=True).iloc[MAX_LAG:]
            cut = int(len(yt) * 0.8)
            y_te = yt.iloc[cut:]
        else:
            _, _, _, y_te = train_test_split(X, y, test_size=0.10, random_state=SEED)
        stats[ds] = {
            "std":  float(y_te.std()),
            "mean": float(y_te.mean()),
            "n":    len(y_te),
        }
    return stats


def compute_cdgi(master: pd.DataFrame, stats: dict) -> pd.DataFrame:
    """Per-model geometric mean of (1 - NRMSE) across all datasets.

    Two passes:
      (1) per-fixed-model rows for baselines that appear in all four datasets;
      (2) one aggregate PRISM row that picks the best PRISM variant per dataset.
    """
    pivot = master.pivot_table(index=["stage", "model"], columns="dataset", values="RMSE")
    nrmse = pivot.copy()
    for ds in pivot.columns:
        nrmse[ds] = pivot[ds] / stats[ds]["std"]
    full = nrmse.dropna(how="any")
    score = (1.0 - full).clip(lower=1e-6)
    cdgi = score.apply(lambda r: float(np.exp(np.log(r).mean())), axis=1)
    out = cdgi.sort_values(ascending=False).rename("CDGI").reset_index()

    # Aggregate PRISM: best of PRISM-* per dataset
    prism_rows = master[master["stage"].str.startswith(("2a", "2b"))]
    prism_best = prism_rows.loc[prism_rows.groupby("dataset")["R2"].idxmax()]
    prism_nrmse = {r["dataset"]: r["RMSE"] / stats[r["dataset"]]["std"]
                   for _, r in prism_best.iterrows()}
    if len(prism_nrmse) == 4:
        score_p = np.array([1 - v for v in prism_nrmse.values()]).clip(min=1e-6)
        cdgi_p = float(np.exp(np.log(score_p).mean()))
        out = pd.concat([
            pd.DataFrame([{"stage": "PRISM (aggregate)", "model": "PRISM",
                           "CDGI": cdgi_p}]),
            out,
        ], ignore_index=True)
    return out.sort_values("CDGI", ascending=False).reset_index(drop=True)


def collect_prism_per_dataset(master: pd.DataFrame) -> dict:
    """Best PRISM result per dataset (whichever stage produced it)."""
    p = master[master["stage"].str.startswith("2a") | master["stage"].str.startswith("2b")]
    res = {}
    for ds, sub in p.groupby("dataset"):
        best = sub.loc[sub["R2"].idxmax()]
        res[ds] = best.to_dict()
    return res


def compute_dsrr(master: pd.DataFrame, stats: dict) -> pd.DataFrame:
    """Per-(model, time-series dataset) DSRR plus a relative form."""
    ts = ["Appliances", "PM25"]
    rows = []
    for ds in ts:
        sub = master[master["dataset"] == ds].copy()
        sub["NRMSE"] = sub["RMSE"] / stats[ds]["std"]
        sub["DSRR"] = (1.0 - sub["NRMSE"]).clip(lower=-1.0)
        # find PRISM and best non-PRISM for relative ratio
        prism_mask = sub["stage"].str.startswith(("2a", "2b"))
        prism_dsrr = float(sub[prism_mask]["DSRR"].max())
        non_prism_dsrr = float(sub[~prism_mask]["DSRR"].max())
        for _, r in sub.iterrows():
            ratio = (r["DSRR"] / non_prism_dsrr) if non_prism_dsrr > 1e-6 else float("inf")
            rows.append({
                "dataset": ds, "stage": r["stage"], "model": r["model"],
                "RMSE": r["RMSE"], "R2": r["R2"],
                "NRMSE": r["NRMSE"], "DSRR": r["DSRR"],
                "DSRR_vs_best_non_prism": ratio,
            })
    return pd.DataFrame(rows).sort_values(["dataset", "DSRR"], ascending=[True, False])


def compute_dmu(master: pd.DataFrame) -> pd.DataFrame:
    """DMU = (RMSE_lagonly - RMSE_VMD) / RMSE_lagonly per time-series dataset."""
    rows = []
    for ds in ["Appliances", "PM25"]:
        sub = master[master["dataset"] == ds]
        # locate VMD and LagOnly within PRISM stage
        vmd  = sub[sub["model"] == "PRISM-TS-VMD"]
        lago = sub[sub["model"] == "PRISM-TS-LagOnly"]
        if vmd.empty or lago.empty:
            rows.append({"dataset": ds, "RMSE_lagonly": float("nan"),
                         "RMSE_vmd": float("nan"), "DMU": float("nan"),
                         "note": "missing one of (LagOnly, VMD) for clean DMU"})
            continue
        rmse_lago = float(lago["RMSE"].iloc[0])
        rmse_vmd  = float(vmd["RMSE"].iloc[0])
        rows.append({
            "dataset": ds,
            "RMSE_lagonly": rmse_lago,
            "RMSE_vmd": rmse_vmd,
            "DMU": (rmse_lago - rmse_vmd) / rmse_lago,
            "note": "",
        })
    return pd.DataFrame(rows)


def main():
    master = pd.read_csv(RES / "master_table.csv")
    extra = RES / "prism_ts" / "Appliances_lagonly.csv"
    if extra.exists():
        e = pd.read_csv(extra)
        e["stage"] = "2b_prism_ts"
        common = [c for c in master.columns if c in e.columns]
        master = pd.concat([master, e[common]], ignore_index=True)
    stats = y_test_stats()
    print("=== test-set y stats ===")
    print(pd.DataFrame(stats).T)

    cdgi = compute_cdgi(master, stats)
    cdgi.to_csv(RES / "custom_CDGI.csv", index=False)
    cdgi.to_markdown(RES / "custom_CDGI.md", index=False, floatfmt=".4f")
    print("\n=== CDGI (cross-domain generalization, higher is better) ===")
    print(cdgi.to_string(index=False))

    dsrr = compute_dsrr(master, stats)
    dsrr.to_csv(RES / "custom_DSRR.csv", index=False)
    dsrr.to_markdown(RES / "custom_DSRR.md", index=False, floatfmt=".4f")
    print("\n=== DSRR (distribution-shift robustness, higher is better) ===")
    print(dsrr.to_string(index=False))

    dmu = compute_dmu(master)
    dmu.to_csv(RES / "custom_DMU.csv", index=False)
    dmu.to_markdown(RES / "custom_DMU.md", index=False, floatfmt=".4f")
    print("\n=== DMU (decomposition marginal utility) ===")
    print(dmu.to_string(index=False))


if __name__ == "__main__":
    main()
