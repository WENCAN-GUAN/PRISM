"""Lag/rolling-feature baselines for the time-series datasets.

Same four learners as 00_baselines.py, but the inputs for Appliances and
PM2.5 are augmented with lag and rolling-window statistics of the target
plus sin/cos cyclical encodings. These are the "+lag" rows in the paper's
master table, and they are the strongest non-PRISM competitors on the
two time-series datasets.
"""
from __future__ import annotations
import sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
import lightgbm as lgb

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import (
    load_dataset, all_metrics, set_seed, ensure_dir,
    add_lag_features, add_cyclical_time,
)

SEED = 42
N_JOBS = 8
TIME_SERIES = ["Appliances", "PM25"]
RESULTS = ensure_dir(Path(__file__).resolve().parents[1] / "results" / "features_ts")


def chrono_split(X: pd.DataFrame, y: pd.Series, ratio: float = 0.8):
    cut = int(len(X) * ratio)
    return X.iloc[:cut], X.iloc[cut:], y.iloc[:cut], y.iloc[cut:]


def get_models() -> dict:
    return {
        "Ridge":        Ridge(alpha=1.0, random_state=SEED),
        "RandomForest": RandomForestRegressor(n_estimators=300, n_jobs=N_JOBS, random_state=SEED),
        "XGBoost":      xgb.XGBRegressor(
            n_estimators=500, learning_rate=0.05, max_depth=6,
            subsample=0.9, colsample_bytree=0.9, random_state=SEED,
            tree_method="hist", n_jobs=N_JOBS, verbosity=0,
        ),
        "LightGBM":     lgb.LGBMRegressor(
            n_estimators=500, learning_rate=0.05, num_leaves=63,
            subsample=0.9, colsample_bytree=0.9, random_state=SEED,
            n_jobs=N_JOBS, verbosity=-1,
        ),
    }


def run(name: str) -> pd.DataFrame:
    set_seed(SEED)
    X, y, meta = load_dataset(name)
    print(f"\n=== {name}  raw shape=({meta.n_samples}, {meta.n_features}) ===")

    Xc = add_cyclical_time(X)
    Xfe, yfe = add_lag_features(Xc, y, target_name=meta.target.replace(".", "_"))
    print(f"  after FE: shape={Xfe.shape}  (kept {len(Xfe)}/{meta.n_samples} rows)")

    Xtr, Xte, ytr, yte = chrono_split(Xfe, yfe)
    sc = StandardScaler().fit(Xtr)
    Xtr_s = pd.DataFrame(sc.transform(Xtr), columns=Xtr.columns, index=Xtr.index)
    Xte_s = pd.DataFrame(sc.transform(Xte), columns=Xte.columns, index=Xte.index)

    rows = []
    for mname, model in get_models().items():
        Xa, Xb = (Xtr_s, Xte_s) if mname == "Ridge" else (Xtr, Xte)
        t0 = time.perf_counter()
        model.fit(Xa, ytr)
        pred = model.predict(Xb)
        dt = time.perf_counter() - t0
        m = all_metrics(yte, pred)
        m.update({"dataset": name, "model": mname, "fit_predict_sec": round(dt, 3)})
        rows.append(m)
        print(f"  {mname:<14}  RMSE={m['RMSE']:.4f}  MAE={m['MAE']:.4f}  "
              f"MAPE={m['MAPE']:.2f}%  R2={m['R2']:.4f}  ({dt:.1f}s)")
    return pd.DataFrame(rows)


def main():
    all_rows = []
    for name in TIME_SERIES:
        df = run(name)
        df.to_csv(RESULTS / f"features_{name}.csv", index=False)
        all_rows.append(df)
    summary = pd.concat(all_rows, ignore_index=True)
    summary = summary[["dataset", "model", "RMSE", "MAE", "MAPE", "R2", "fit_predict_sec"]]
    summary.to_csv(RESULTS / "features_summary.csv", index=False)
    summary.to_markdown(RESULTS / "features_summary.md", index=False, floatfmt=".4f")
    print(f"\nSaved → {RESULTS}")
    print("\n" + summary.to_string(index=False))

    # Compare against stage-0 baselines
    base_path = Path(__file__).resolve().parents[1] / "results" / "baselines" / "baseline_summary.csv"
    if base_path.exists():
        base = pd.read_csv(base_path)
        base = base[base["dataset"].isin(TIME_SERIES)][["dataset", "model", "RMSE", "R2"]]
        base = base.rename(columns={"RMSE": "RMSE_baseline", "R2": "R2_baseline"})
        cmp = summary[["dataset", "model", "RMSE", "R2"]].merge(base, on=["dataset", "model"])
        cmp["ΔRMSE"] = cmp["RMSE"] - cmp["RMSE_baseline"]
        cmp["ΔR2"]   = cmp["R2"]   - cmp["R2_baseline"]
        cmp.to_csv(RESULTS / "features_vs_baseline.csv", index=False)
        cmp.to_markdown(RESULTS / "features_vs_baseline.md", index=False, floatfmt=".4f")
        print("\n[FE vs baseline]")
        print(cmp.to_string(index=False))


if __name__ == "__main__":
    main()
