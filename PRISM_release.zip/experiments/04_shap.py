"""TreeSHAP attributions for PRISM on the static datasets.

Reads back the best LightGBM hyper-parameters saved by 02a_prism_static.py,
refits the model on training+validation, and computes TreeSHAP on a sample
of the test set. Writes the importance bar plot and the beeswarm plot for
each of CCPP and Concrete. For the time-series datasets we compute SHAP on
the dominant low-frequency VMD mode (lag features dominate the higher modes,
so attributions there are not particularly informative).
"""
from __future__ import annotations
import sys, json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import shap
from sklearn.model_selection import train_test_split

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prism import load_dataset, ensure_dir, set_seed
from prism.tuning import fit_lgbm

SEED = 42
ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"
OUT = ensure_dir(RES / "shap")
SAMPLE_N = 1500


def shap_static(name: str):
    set_seed(SEED)
    p_params = RES / "prism_static" / f"{name}_best_params.json"
    if not p_params.exists():
        print(f"[skip] {name}: best params not found yet")
        return
    with p_params.open() as f:
        best = json.load(f)
    X, y, _ = load_dataset(name)
    Xtv, Xte, ytv, yte = train_test_split(X, y, test_size=0.10, random_state=SEED)
    model = fit_lgbm(best, Xtv, ytv, n_jobs=8, seed=SEED)
    Xs = Xte.sample(min(SAMPLE_N, len(Xte)), random_state=SEED)
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(Xs)

    fig = plt.figure(figsize=(6, 4))
    shap.summary_plot(shap_values, Xs, plot_type="bar", show=False)
    plt.tight_layout(); plt.savefig(OUT / f"{name}_shap_bar.png", dpi=200); plt.close()

    fig = plt.figure(figsize=(6, 5))
    shap.summary_plot(shap_values, Xs, show=False)
    plt.tight_layout(); plt.savefig(OUT / f"{name}_shap_beeswarm.png", dpi=200); plt.close()
    print(f"[ok] {name}  saved bar + beeswarm")


def main():
    for ds in ["CCPP", "Concrete"]:
        shap_static(ds)
    print(f"SHAP plots → {OUT}")


if __name__ == "__main__":
    main()
