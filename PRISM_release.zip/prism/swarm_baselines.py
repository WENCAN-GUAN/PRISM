"""Minimal implementations of GA, PSO, GWO, and random search for comparison
against ICPO on the LightGBM hyperparameter task."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable
import numpy as np


@dataclass
class OptResult:
    best_x: np.ndarray
    best_fitness: float
    history: list[float] = field(default_factory=list)


def _evaluate(f, X):
    return np.array([f(x) for x in X])


def random_search(f, lb, ub, n_evals=300, seed=42) -> OptResult:
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    best_x, best_f, hist = None, float("inf"), []
    for _ in range(n_evals):
        x = rng.uniform(lb, ub)
        v = f(x)
        if v < best_f:
            best_f, best_x = float(v), x.copy()
        hist.append(best_f)
    return OptResult(best_x=best_x, best_fitness=best_f, history=hist)


def pso(f, lb, ub, pop_size=15, max_iter=20,
        w=0.7, c1=1.5, c2=1.5, seed=42) -> OptResult:
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    dim = len(lb)
    X = rng.uniform(lb, ub, (pop_size, dim))
    V = np.zeros_like(X)
    F = _evaluate(f, X)
    pbest, pbest_F = X.copy(), F.copy()
    g_idx = int(np.argmin(F))
    gbest, gbest_F = X[g_idx].copy(), float(F[g_idx])
    hist = [gbest_F]
    for _ in range(max_iter):
        r1 = rng.uniform(size=(pop_size, dim))
        r2 = rng.uniform(size=(pop_size, dim))
        V = w * V + c1 * r1 * (pbest - X) + c2 * r2 * (gbest - X)
        X = np.clip(X + V, lb, ub)
        F = _evaluate(f, X)
        better = F < pbest_F
        pbest_F = np.where(better, F, pbest_F)
        pbest = np.where(better[:, None], X, pbest)
        idx = int(np.argmin(F))
        if F[idx] < gbest_F:
            gbest_F = float(F[idx]); gbest = X[idx].copy()
        hist.append(gbest_F)
    return OptResult(best_x=gbest, best_fitness=gbest_F, history=hist)


def ga(f, lb, ub, pop_size=15, max_iter=20,
       mutation_rate=0.15, seed=42) -> OptResult:
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    dim = len(lb)
    X = rng.uniform(lb, ub, (pop_size, dim))
    F = _evaluate(f, X)
    g_idx = int(np.argmin(F))
    best_x, best_f = X[g_idx].copy(), float(F[g_idx])
    hist = [best_f]
    for _ in range(max_iter):
        new_X = []
        for _ in range(pop_size):
            a, b = rng.choice(pop_size, 2, replace=False)
            p1 = X[a if F[a] < F[b] else b]
            a, b = rng.choice(pop_size, 2, replace=False)
            p2 = X[a if F[a] < F[b] else b]
            mask = rng.random(dim) < 0.5
            child = np.where(mask, p1, p2).astype(float)
            for j in range(dim):
                if rng.random() < mutation_rate:
                    child[j] = rng.uniform(lb[j], ub[j])
            new_X.append(child)
        X = np.clip(np.array(new_X), lb, ub)
        F = _evaluate(f, X)
        idx = int(np.argmin(F))
        if F[idx] < best_f:
            best_f, best_x = float(F[idx]), X[idx].copy()
        hist.append(best_f)
    return OptResult(best_x=best_x, best_fitness=best_f, history=hist)


def gwo(f, lb, ub, pop_size=15, max_iter=20, seed=42) -> OptResult:
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    dim = len(lb)
    X = rng.uniform(lb, ub, (pop_size, dim))
    F = _evaluate(f, X)
    best_x, best_f = X[int(np.argmin(F))].copy(), float(F.min())
    hist = [best_f]
    for t in range(max_iter):
        order = np.argsort(F)
        alpha, beta, delta = X[order[0]], X[order[1]], X[order[2]]
        a = 2 - 2 * t / max_iter
        for i in range(pop_size):
            A1 = a * (2 * rng.uniform(size=dim) - 1)
            A2 = a * (2 * rng.uniform(size=dim) - 1)
            A3 = a * (2 * rng.uniform(size=dim) - 1)
            C1 = 2 * rng.uniform(size=dim)
            C2 = 2 * rng.uniform(size=dim)
            C3 = 2 * rng.uniform(size=dim)
            D_a = np.abs(C1 * alpha - X[i])
            D_b = np.abs(C2 * beta  - X[i])
            D_d = np.abs(C3 * delta - X[i])
            X[i] = (alpha - A1 * D_a + beta - A2 * D_b + delta - A3 * D_d) / 3.0
        X = np.clip(X, lb, ub)
        F = _evaluate(f, X)
        idx = int(np.argmin(F))
        if F[idx] < best_f:
            best_f, best_x = float(F[idx]), X[idx].copy()
        hist.append(best_f)
    return OptResult(best_x=best_x, best_fitness=best_f, history=hist)
