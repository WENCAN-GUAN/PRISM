"""GPU deep-learning regressors for PRISM benchmark.

A compact MLP and an FT-Transformer-lite, both trained with cosine LR + early
stopping. Designed to run on a single CUDA device (use CUDA_VISIBLE_DEVICES
to pin to a specific GPU).
"""
from __future__ import annotations
import math
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset


def _device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


class MLPRegressor(nn.Module):
    def __init__(self, in_dim: int, hidden: tuple[int, ...] = (256, 256, 128), dropout: float = 0.15):
        super().__init__()
        layers, last = [], in_dim
        for h in hidden:
            layers += [nn.Linear(last, h), nn.GELU(), nn.BatchNorm1d(h), nn.Dropout(dropout)]
            last = h
        layers.append(nn.Linear(last, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).squeeze(-1)


class FTTransformerLite(nn.Module):
    """Compact Feature-Tokenizer Transformer for tabular regression."""

    def __init__(self, in_dim: int, d_token: int = 64, n_heads: int = 4,
                 n_layers: int = 3, dropout: float = 0.1):
        super().__init__()
        self.tokenizer = nn.Linear(1, d_token)
        self.feature_bias = nn.Parameter(torch.zeros(in_dim, d_token))
        self.cls = nn.Parameter(torch.zeros(1, 1, d_token))
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_token, nhead=n_heads, dim_feedforward=d_token * 4,
            dropout=dropout, batch_first=True, activation="gelu", norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.head = nn.Sequential(nn.LayerNorm(d_token), nn.Linear(d_token, 1))

    def forward(self, x):
        b, f = x.shape
        tokens = self.tokenizer(x.unsqueeze(-1)) + self.feature_bias.unsqueeze(0)
        cls = self.cls.expand(b, -1, -1)
        h = torch.cat([cls, tokens], dim=1)
        h = self.encoder(h)
        return self.head(h[:, 0]).squeeze(-1)


def _make_loader(X: np.ndarray, y: np.ndarray, batch_size: int, shuffle: bool):
    X_t = torch.tensor(X, dtype=torch.float32)
    y_t = torch.tensor(y, dtype=torch.float32)
    return DataLoader(TensorDataset(X_t, y_t), batch_size=batch_size, shuffle=shuffle, drop_last=False)


def train_torch_regressor(
    model: nn.Module,
    X_tr: np.ndarray, y_tr: np.ndarray,
    X_val: np.ndarray, y_val: np.ndarray,
    epochs: int = 200, batch_size: int = 256,
    lr: float = 1e-3, weight_decay: float = 1e-4,
    patience: int = 25, seed: int = 42, verbose: bool = False,
) -> dict:
    torch.manual_seed(seed)
    dev = _device()
    model.to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = nn.MSELoss()

    train_loader = _make_loader(X_tr, y_tr, batch_size, shuffle=True)
    Xv = torch.tensor(X_val, dtype=torch.float32, device=dev)
    yv = torch.tensor(y_val, dtype=torch.float32, device=dev)

    best_state, best_val, no_improve = None, math.inf, 0
    history = []
    for ep in range(epochs):
        model.train()
        tr_loss = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(dev, non_blocking=True), yb.to(dev, non_blocking=True)
            opt.zero_grad()
            loss = crit(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            tr_loss += loss.item() * xb.size(0)
        tr_loss /= len(train_loader.dataset)
        sched.step()

        model.eval()
        with torch.no_grad():
            val_pred = model(Xv)
            val_loss = float(crit(val_pred, yv).item())
        history.append((tr_loss, val_loss))

        if val_loss < best_val - 1e-6:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= patience:
                break
        if verbose and (ep % 10 == 0 or ep == epochs - 1):
            print(f"    ep{ep:3d}  train={tr_loss:.4f}  val={val_loss:.4f}")

    if best_state is not None:
        model.load_state_dict(best_state)
    return {"history": history, "best_val_mse": best_val, "epochs_ran": len(history)}


@torch.no_grad()
def predict(model: nn.Module, X: np.ndarray, batch_size: int = 1024) -> np.ndarray:
    model.eval()
    dev = next(model.parameters()).device
    out = []
    for i in range(0, len(X), batch_size):
        xb = torch.tensor(X[i:i + batch_size], dtype=torch.float32, device=dev)
        out.append(model(xb).cpu().numpy())
    return np.concatenate(out, axis=0)
