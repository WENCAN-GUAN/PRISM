"""PRISM — Predictive Regression with Intelligent Swarm-tuned Mode-decomposition."""
from .data import load_dataset, ALL_DATASETS, DatasetMeta
from .metrics import all_metrics, rmse, mae, mape, r2
from .utils import set_seed, timer, ensure_dir
from .features import add_lag_features, add_cyclical_time

__all__ = [
    "load_dataset", "ALL_DATASETS", "DatasetMeta",
    "all_metrics", "rmse", "mae", "mape", "r2",
    "set_seed", "timer", "ensure_dir",
    "add_lag_features", "add_cyclical_time",
]
