"""Utility helpers."""
from __future__ import annotations
import os, random, time
from contextlib import contextmanager
from pathlib import Path
import numpy as np


def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


@contextmanager
def timer(label: str = ""):
    t0 = time.perf_counter()
    yield
    dt = time.perf_counter() - t0
    print(f"[{label}] {dt:.2f}s")


def ensure_dir(p: str | Path) -> Path:
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    return p
