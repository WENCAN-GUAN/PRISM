"""Unified data loaders for the four PRISM benchmark datasets."""
from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path
import pandas as pd
import numpy as np

# Data root resolution order:
#   1. environment variable PRISM_DATA_DIR (if set)
#   2. <repo>/datasets/  (default; assumes the package sits at <repo>/prism/)
ROOT = Path(
    os.environ.get("PRISM_DATA_DIR")
    or Path(__file__).resolve().parents[1] / "datasets"
)


@dataclass
class DatasetMeta:
    name: str
    target: str
    is_time_series: bool
    n_samples: int
    n_features: int
    feature_names: list[str]


def _load_ccpp() -> tuple[pd.DataFrame, pd.Series, DatasetMeta]:
    df = pd.read_excel(ROOT / "01_CCPP/CCPP/Folds5x2_pp.xlsx")
    y = df["PE"]
    X = df.drop(columns=["PE"])
    meta = DatasetMeta("CCPP", "PE", False, *X.shape, list(X.columns))
    return X, y, meta


def _load_concrete() -> tuple[pd.DataFrame, pd.Series, DatasetMeta]:
    df = pd.read_excel(ROOT / "02_Concrete/Concrete_Data.xls")
    df.columns = [c.strip() for c in df.columns]
    target = [c for c in df.columns if c.lower().startswith("concrete compressive")][0]
    short = {
        "Cement (component 1)(kg in a m^3 mixture)": "cement",
        "Blast Furnace Slag (component 2)(kg in a m^3 mixture)": "slag",
        "Fly Ash (component 3)(kg in a m^3 mixture)": "fly_ash",
        "Water  (component 4)(kg in a m^3 mixture)": "water",
        "Water (component 4)(kg in a m^3 mixture)": "water",
        "Superplasticizer (component 5)(kg in a m^3 mixture)": "superplasticizer",
        "Coarse Aggregate  (component 6)(kg in a m^3 mixture)": "coarse_agg",
        "Coarse Aggregate (component 6)(kg in a m^3 mixture)": "coarse_agg",
        "Fine Aggregate (component 7)(kg in a m^3 mixture)": "fine_agg",
        "Age (day)": "age",
        target: "strength",
    }
    df = df.rename(columns=short)
    y = df["strength"]
    X = df.drop(columns=["strength"])
    meta = DatasetMeta("Concrete", "strength", False, *X.shape, list(X.columns))
    return X, y, meta


def _load_appliances() -> tuple[pd.DataFrame, pd.Series, DatasetMeta]:
    df = pd.read_csv(ROOT / "03_AppliancesEnergy/energydata_complete.csv")
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)
    df["hour"] = df["date"].dt.hour
    df["dayofweek"] = df["date"].dt.dayofweek
    df["month"] = df["date"].dt.month
    # rv1, rv2 are random variables per UCI readme — drop
    df = df.drop(columns=["rv1", "rv2", "date"])
    y = df["Appliances"].astype(float)
    X = df.drop(columns=["Appliances"])
    meta = DatasetMeta("Appliances", "Appliances", True, *X.shape, list(X.columns))
    return X, y, meta


def _load_pm25() -> tuple[pd.DataFrame, pd.Series, DatasetMeta]:
    df = pd.read_csv(ROOT / "04_BeijingPM25/PRSA_data_2010.1.1-2014.12.31.csv")
    df = df.dropna(subset=["pm2.5"]).reset_index(drop=True)
    df = df.drop(columns=["No"])
    df = pd.get_dummies(df, columns=["cbwd"], drop_first=False, dtype=float)
    y = df["pm2.5"]
    X = df.drop(columns=["pm2.5"])
    meta = DatasetMeta("PM25", "pm2.5", True, *X.shape, list(X.columns))
    return X, y, meta


_LOADERS = {
    "CCPP":       _load_ccpp,
    "Concrete":   _load_concrete,
    "Appliances": _load_appliances,
    "PM25":       _load_pm25,
}

ALL_DATASETS = list(_LOADERS.keys())


def load_dataset(name: str) -> tuple[pd.DataFrame, pd.Series, DatasetMeta]:
    if name not in _LOADERS:
        raise ValueError(f"Unknown dataset: {name}. Choose from {ALL_DATASETS}")
    return _LOADERS[name]()
