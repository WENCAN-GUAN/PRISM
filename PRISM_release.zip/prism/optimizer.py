"""Improved Crested Porcupine Optimizer (ICPO) — the 'I' in PRISM.

Base algorithm: Crested Porcupine Optimizer (Abdel-Basset et al., 2024).
Improvements added here (the novelty for the paper):
  1. Tent-chaotic initialization for better population diversity.
  2. Levy-flight perturbation in the third defensive mechanism.
  3. Adaptive elite-guided strategy: best agent is mixed in with weight that
     anneals from 0 to 0.3 over the run, accelerating late-stage convergence.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from math import gamma as _gamma
from typing import Callable
import numpy as np


def _tent_chaos(n: int, dim: int, mu: float = 0.7, rng: np.random.Generator | None = None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    x = rng.uniform(0, 1, size=dim)
    out = np.empty((n, dim))
    out[0] = x
    for i in range(1, n):
        x = np.where(x < mu, x / mu, (1 - x) / (1 - mu))
        out[i] = x
    return out


def _levy(dim: int, beta: float = 1.5, rng: np.random.Generator | None = None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    sigma = (
        _gamma(1 + beta) * np.sin(np.pi * beta / 2)
        / (_gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))
    ) ** (1 / beta)
    u = rng.normal(0, sigma, size=dim)
    v = rng.normal(0, 1, size=dim)
    return u / (np.abs(v) ** (1 / beta) + 1e-12)


@dataclass
class ICPOResult:
    best_x: np.ndarray
    best_fitness: float
    history: list[float] = field(default_factory=list)


class ICPO:
    """Improved Crested Porcupine Optimizer (minimization)."""

    def __init__(
        self,
        objective: Callable[[np.ndarray], float],
        lb: np.ndarray,
        ub: np.ndarray,
        pop_size: int = 30,
        max_iter: int = 50,
        n_min: int = 10,
        cycles: int = 2,
        alpha: float = 0.2,
        seed: int | None = 42,
        use_tent: bool = True,
        use_levy: bool = True,
        use_elite: bool = True,
    ):
        self.f = objective
        self.lb, self.ub = np.asarray(lb, dtype=float), np.asarray(ub, dtype=float)
        self.dim = len(self.lb)
        self.pop_size = pop_size
        self.max_iter = max_iter
        self.n_min = n_min
        self.cycles = cycles
        self.alpha = alpha
        self.rng = np.random.default_rng(seed)
        self.use_tent = use_tent
        self.use_levy = use_levy
        self.use_elite = use_elite

    def _init_pop(self) -> np.ndarray:
        if self.use_tent:
            chaos = _tent_chaos(self.pop_size, self.dim, rng=self.rng)
        else:
            chaos = self.rng.uniform(0, 1, size=(self.pop_size, self.dim))
        return self.lb + chaos * (self.ub - self.lb)

    def _clip(self, x: np.ndarray) -> np.ndarray:
        return np.clip(x, self.lb, self.ub)

    def run(self) -> ICPOResult:
        X = self._init_pop()
        F = np.array([self.f(x) for x in X])
        best_idx = int(np.argmin(F))
        best_x, best_f = X[best_idx].copy(), float(F[best_idx])
        history = [best_f]

        for t in range(1, self.max_iter + 1):
            # Population reduction (CPO original mechanism)
            n_t = int(self.n_min + (self.pop_size - self.n_min) * (
                1 - (t % np.ceil(self.max_iter / self.cycles)) / np.ceil(self.max_iter / self.cycles)
            ))
            n_t = max(self.n_min, min(self.pop_size, n_t))
            elite_w = 0.3 * (t / self.max_iter)  # adaptive elite guidance

            for i in range(n_t):
                r = self.rng.random()
                u1 = self.rng.integers(0, 2, size=self.dim)
                y = (X[i] + X[self.rng.integers(0, n_t)]) / 2.0

                if r < 0.25:  # 1st defense — sight
                    new_x = X[i] + self.rng.normal(size=self.dim) * np.abs(2 * self.rng.random() * best_x - y)
                elif r < 0.5:  # 2nd defense — sound
                    new_x = (1 - u1) * X[i] + u1 * (
                        y + self.rng.random() * (X[self.rng.integers(0, n_t)] - X[self.rng.integers(0, n_t)])
                    )
                elif r < 0.75:  # 3rd defense — odor (+ Levy)
                    s = self.rng.random() * self.alpha
                    perturb = (_levy(self.dim, rng=self.rng) if self.use_levy
                               else self.rng.normal(size=self.dim))
                    new_x = (1 - u1) * X[i] + u1 * (X[self.rng.integers(0, n_t)] + s * perturb)
                else:  # 4th defense — physical attack
                    fit_i = F[i] + 1e-12
                    tau = self.rng.random()
                    new_x = best_x + (self.alpha * (1 - tau) + tau) * (u1 * best_x - X[i]) / fit_i

                # adaptive elite blend
                if self.use_elite:
                    new_x = (1 - elite_w) * new_x + elite_w * best_x
                new_x = self._clip(new_x)
                new_f = self.f(new_x)
                if new_f < F[i]:
                    X[i] = new_x
                    F[i] = new_f
                    if new_f < best_f:
                        best_x, best_f = new_x.copy(), float(new_f)

            history.append(best_f)

        return ICPOResult(best_x=best_x, best_fitness=best_f, history=history)
