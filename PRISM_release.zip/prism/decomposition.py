"""Signal decomposition wrappers — the 'M' (mode-decomposition) in PRISM.

Provides a uniform interface over CEEMDAN and (optional) VMD.
Used only for time-series targets (Appliances, PM25). For static datasets
(CCPP, Concrete) decomposition is skipped.
"""
from __future__ import annotations
import numpy as np


def ceemdan_decompose(y: np.ndarray, trials: int = 50, seed: int = 42) -> np.ndarray:
    """Return matrix of shape (n_imfs, n_samples)."""
    try:
        from PyEMD import CEEMDAN
    except ImportError as e:
        raise ImportError("Install PyEMD: pip install EMD-signal") from e
    ceemdan = CEEMDAN(trials=trials, parallel=True, processes=8)
    ceemdan.noise_seed(seed)
    imfs = ceemdan(np.asarray(y, dtype=float))
    return imfs  # (k, n)


def vmd_decompose(y: np.ndarray, K: int = 8, alpha: float = 2000,
                  tau: float = 0.0, DC: bool = False, init: int = 1, tol: float = 1e-7) -> np.ndarray:
    """VMD — returns (K, n) matrix of modes."""
    try:
        from vmdpy import VMD
    except ImportError as e:
        raise ImportError("Install vmdpy: pip install vmdpy") from e
    u, _, _ = VMD(np.asarray(y, dtype=float), alpha, tau, K, DC, init, tol)
    return u  # (K, n)


def reconstruct(imfs: np.ndarray) -> np.ndarray:
    """Sum of modes — used as a sanity-check of decomposition fidelity."""
    return np.sum(imfs, axis=0)
