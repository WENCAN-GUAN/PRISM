"""Time-series feature engineering for PRISM.

For Appliances and PM25 we add:
  - Lag features at multiple horizons
  - Rolling-window statistics (mean, std, min, max)
  - Cyclical encodings of hour-of-day, month, day-of-week
"""
from __future__ import annotations
import numpy as np
import pandas as pd


DEFAULT_LAGS = (1, 2, 3, 6, 12, 24)
DEFAULT_WINDOWS = (3, 6, 12, 24)


def add_lag_features(
    X: pd.DataFrame,
    y: pd.Series,
    lags: tuple[int, ...] = DEFAULT_LAGS,
    windows: tuple[int, ...] = DEFAULT_WINDOWS,
    target_name: str = "y",
) -> tuple[pd.DataFrame, pd.Series]:
    """Append lag/rolling stats of the target to X. Drops rows with NaNs introduced."""
    df = X.copy()
    s = y.reset_index(drop=True)
    df = df.reset_index(drop=True)

    for L in lags:
        df[f"{target_name}_lag{L}"] = s.shift(L)

    shifted = s.shift(1)
    for w in windows:
        roll = shifted.rolling(window=w, min_periods=w)
        df[f"{target_name}_rmean{w}"] = roll.mean()
        df[f"{target_name}_rstd{w}"]  = roll.std()
        df[f"{target_name}_rmin{w}"]  = roll.min()
        df[f"{target_name}_rmax{w}"]  = roll.max()

    max_drop = max(max(lags), max(windows))
    df = df.iloc[max_drop:].reset_index(drop=True)
    y_out = s.iloc[max_drop:].reset_index(drop=True)
    return df, y_out


def add_cyclical_time(
    df: pd.DataFrame,
    hour_col: str | None = "hour",
    dayofweek_col: str | None = "dayofweek",
    month_col: str | None = "month",
) -> pd.DataFrame:
    """Replace ordinal time columns with sin/cos cyclical encodings."""
    out = df.copy()
    pairs = [(hour_col, 24), (dayofweek_col, 7), (month_col, 12)]
    for col, period in pairs:
        if col is None or col not in out.columns:
            continue
        v = out[col].to_numpy(dtype=float)
        out[f"{col}_sin"] = np.sin(2 * np.pi * v / period)
        out[f"{col}_cos"] = np.cos(2 * np.pi * v / period)
        out = out.drop(columns=[col])
    return out
