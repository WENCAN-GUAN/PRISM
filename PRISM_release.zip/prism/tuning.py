"""ICPO-driven hyperparameter tuning for tree-based regressors."""
from __future__ import annotations
import numpy as np
import lightgbm as lgb

from .optimizer import ICPO, ICPOResult
from .metrics import rmse


LGBM_BOUNDS = {
    "learning_rate":     (0.01, 0.30),
    "n_estimators":      (100,  1000),
    "num_leaves":        (15,   255),
    "max_depth":         (3,    15),
    "min_child_samples": (5,    100),
    "subsample":         (0.5,  1.0),
    "colsample_bytree":  (0.5,  1.0),
    "reg_alpha":         (0.0,  5.0),
    "reg_lambda":        (0.0,  5.0),
}
LGBM_INT = {"n_estimators", "num_leaves", "max_depth", "min_child_samples"}


def decode_lgbm(theta: np.ndarray, names: list[str]) -> dict:
    out = {}
    for v, n in zip(theta, names):
        out[n] = int(round(float(v))) if n in LGBM_INT else float(v)
    return out


def tune_lightgbm(
    X_tr, y_tr, X_val, y_val,
    n_jobs: int = 6,
    pop_size: int = 15,
    max_iter: int = 20,
    seed: int = 42,
    use_tent: bool = True,
    use_levy: bool = True,
    use_elite: bool = True,
) -> tuple[dict, ICPOResult]:
    names = list(LGBM_BOUNDS.keys())
    lb = np.array([LGBM_BOUNDS[n][0] for n in names], dtype=float)
    ub = np.array([LGBM_BOUNDS[n][1] for n in names], dtype=float)

    def objective(theta: np.ndarray) -> float:
        params = decode_lgbm(theta, names)
        model = lgb.LGBMRegressor(
            **params,
            random_state=seed, n_jobs=n_jobs,
            verbosity=-1, subsample_freq=1, force_col_wise=True,
        )
        model.fit(X_tr, y_tr)
        pred = model.predict(X_val)
        return rmse(y_val, pred)

    icpo = ICPO(objective, lb, ub, pop_size=pop_size, max_iter=max_iter, seed=seed,
                use_tent=use_tent, use_levy=use_levy, use_elite=use_elite)
    result = icpo.run()
    return decode_lgbm(result.best_x, names), result


def fit_lgbm(params: dict, X, y, n_jobs: int = 6, seed: int = 42):
    model = lgb.LGBMRegressor(
        **params, random_state=seed, n_jobs=n_jobs,
        verbosity=-1, subsample_freq=1, force_col_wise=True,
    )
    model.fit(X, y)
    return model
